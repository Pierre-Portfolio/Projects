package cineclub.modeles;

import java.util.ArrayList;

public class ModeleSeances implements InterfaceModeleSeances {

	@Override
	public void ajouterSeance(ModeleSeance s) {
		// TODO Auto-generated method stub

	}

	@Override
	public ArrayList<ModeleSeance> rechercheSeance(String titreFilm) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<ModeleSeance> rechercheSeance(int heureSeance) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
