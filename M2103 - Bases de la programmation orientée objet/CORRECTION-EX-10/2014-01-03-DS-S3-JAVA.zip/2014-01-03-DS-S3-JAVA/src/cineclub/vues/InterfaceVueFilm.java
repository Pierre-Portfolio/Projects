package cineclub.vues;

public interface InterfaceVueFilm {
	public void miseAJour ();
}
