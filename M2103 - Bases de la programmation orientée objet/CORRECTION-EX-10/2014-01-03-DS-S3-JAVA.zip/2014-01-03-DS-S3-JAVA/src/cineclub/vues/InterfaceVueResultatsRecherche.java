package cineclub.vues;

import java.util.ArrayList;

import cineclub.modeles.ModeleSeance;

public interface InterfaceVueResultatsRecherche {
	void afficherResultatsRecherche (ArrayList <ModeleSeance> resultats);
}
