package EX4;
public class Carre extends Rectangle
{
	public void setLargeur(double largeur) {
		super.setLargeur(largeur);
		super.setLongueur(largeur);
	}
	public void setLongueur(double longueur) {
		super.setLargeur(longueur);
		super.setLongueur(longueur);
	}
}