import java.util.Arrays;
public class TestArrays {
    public static void afficher (int t []) {
        System.out.println ();
        for (int i=0; i < t.length; i++)
            System.out.print (t[i] + " ");
    }
    
    public static void main (String args []) {
        int t [] = {3, 6, 1, -10, 5};
        afficher (t);
        Arrays.sort (t);
        afficher (t);
    }
}
