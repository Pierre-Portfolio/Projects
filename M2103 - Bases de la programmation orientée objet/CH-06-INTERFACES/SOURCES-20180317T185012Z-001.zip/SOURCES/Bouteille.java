
public class Bouteille implements Stockable {

	private double valeurUnitaire ; 
	private float volume ;
	
	public double getValeur () {
		return valeurUnitaire * volume ; 
	}
	
	public void commander (int quantite) {
		System.out.println ("Commande de "+ quantite + " bouteilles");
	}
}
