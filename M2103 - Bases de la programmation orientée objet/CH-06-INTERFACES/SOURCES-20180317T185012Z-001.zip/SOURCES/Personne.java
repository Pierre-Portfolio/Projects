import java.util.*;

public class Personne implements Comparable {
	String prenom ; 
	String nom ; 
	int anneeNaissance ;

	// TRI PAR ORDRE ALPHABETIQUE SUR LE NOM : 
	/*public int compareTo(Object o) {
		// Rassurer le compilateur grace � un downcasting
		Personne p = (Personne) o ;
		
		// Comparer selon le nom	
		return nom.compareTo(p.nom);
	} */
	
	// Tester cette classe 
	public static void main (String args []) {
		Personne p0 = new Personne ("Durand", "Albert", 1978);
		Personne p1 = new Personne ("Acap", "Paul", 1975);
		Personne p2 = new Personne ("Durand", "Albert", 1973);

		Personne tp [] = new Personne [3];
		tp [0] = p0 ;
		tp [1] = p1 ;
		tp [2] = p2 ;

		System.out.println ("AVANT LE TRI :");
		afficher (tp); 

		System.out.println ("TRI EN COURS ...");
		Arrays.sort (tp) ;

		System.out.println ("APRES LE TRI :");
		afficher (tp); 
	}
	// Constructeur
	Personne (String nom, String prenom, int anneeNaissance) {
		this.nom = nom ; 
		this.prenom = prenom ; 
		this.anneeNaissance = anneeNaissance ;         
	}

	// Retourner une version chaine de caracteres
	public String toString () {
		return nom.toUpperCase() + " " + prenom + " (" + anneeNaissance + ")";
	}

	
	// Afficher un tableau de personnes
	static void afficher (Personne t[]) {
		System.out.println ();
		for (int i=0; i < t.length; i++)
			System.out.println (t[i] + " ");
	}
	// Pour trier selon l'ann�e de naissance
	public int compareTo(Object o) {
		// Rassurer le compilateur grace � un downcasting
		Personne p = (Personne) o ;
		
		// Comparer selon l'ann�e de naissance
		if (this.anneeNaissance < p.anneeNaissance) 
			return -1 ;
		else if (this.anneeNaissance > p.anneeNaissance) 
			return +1;
		else 
			return 0 ;
	} 
	//------------------------
	
}







