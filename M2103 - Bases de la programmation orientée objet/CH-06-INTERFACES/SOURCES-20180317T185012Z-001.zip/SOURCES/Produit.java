
interface Achetable {
	void getPrix () ;
	String getNom ();
}

abstract public class Produit implements Achetable {
	String nom ;
	public String getNom () {
		return nom ; 
	}
}