
public interface I1 {
	void m1();
}

interface I2 extends I1 {
	void m2();
}

interface I3 extends I2 {
	void m3();
}

class C implements I3 {

	@Override
	public void m2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void m1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void m3() {
		// TODO Auto-generated method stub
		
	}
	
}
