
public interface Stockable {
	// D�finition de constantes
	final static int VOLUME_MAX = 1000 ;
	
	// D�finition de m�thodes
	void commander (int quantiteArticles);
	double getValeur ();
}

