import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class FrameButtonEcouteurAnonyme {
	public static void main (String args []) {                        
		// Creer un bouton
		final JButton b = new JButton ("Bonjour");

		// Enregistrer un  �couteur aupr�s du bouton
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				System.out.println("On a clique sur : "+ b.getText());
			}
		});
		
		// Creer une fenetre et y ajouter le bouton
		JFrame f = new JFrame ("Fenetre");
		f.add (b);
		f.setSize (300, 200);
		f.setVisible (true);
	}
}
