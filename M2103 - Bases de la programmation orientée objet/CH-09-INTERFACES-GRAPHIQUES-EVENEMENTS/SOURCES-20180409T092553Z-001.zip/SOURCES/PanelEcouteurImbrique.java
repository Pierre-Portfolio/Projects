import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

// CLASSE ECOUTEUR IMBRIQUEE ET NON ANONYME
public class PanelEcouteurImbrique extends JPanel {
	JButton b ;
	JTextField txt ;
	
	PanelEcouteurImbrique () {
		// Creer les composants et les ajouter au panel
		b = new JButton ("Afficher");
		txt = new JTextField(20);
		add (b);
		add (txt);
		
		// Creer un objet ecouteur
        EcouteurImbrique ecouteur = new EcouteurImbrique();
        
        // Dire au bouton d'ajouter a sa liste de listener le listener
        // que l'on vient de creer 
        b.addActionListener (ecouteur);
	}
	
	// La classe �couteur est interne � la classe principale
	// donc les m�thodes ont acc�s � tous les attributs
	public class EcouteurImbrique implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			System.out.println ("Contenu du champs de texte : " + 
		          txt.getText());
		}
	}
	
	public static void main (String args []) {                        
		// Creer un bouton
		PanelEcouteurImbrique p = new PanelEcouteurImbrique();

		// Creer une fenetre et y ajouter le bouton
        JFrame f = new JFrame ("Fenetre");
        f.add (p);
        f.setSize (300, 200);
        f.setVisible (true);
    }
}
