import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import javax.swing.JButton;

public class EcouteurAfficheActionEvent implements ActionListener {
	public void actionPerformed(ActionEvent e) {		
		// Afficher la date et l'heure de l'�v�nement
		System.out.println ("-------------------------------");
		System.out.println (new Date(e.getWhen()));

   		// Afficher l'identificateur de l'evenement
   		if (e.getID() == ActionEvent.ACTION_PERFORMED) 
	   		System.out.println ("e.getID() == Event Id: ACTION_PERFORMED");

   		// Afficher la classe de la source de l��v�nement
   		String source = e.getSource().getClass().getName();
   		System.out.println("Classe source de l'�v�nement : " + source);

   		// Si c'est un bouton, afficher son nom
   		if (e.getSource() instanceof JButton) {
   			// Caster l'objet source de l'�v�nement en JButton
   			JButton boutonSource = (JButton) e.getSource();
       		System.out.println("Nom du bouton : " + 
       				boutonSource.getText());    			     		
   		}
   			
   		// Afficher les modifieurs (touches du claviers appuy�es en m�me temps que le clic)
    	int mod = e.getModifiers();
    	String m = "";
    	if ((mod & ActionEvent.ALT_MASK) > 0) 
        		m += "Alt ";
    	if ((mod & ActionEvent.SHIFT_MASK) > 0) 
	        m += "Shift ";
	       	if ((mod & ActionEvent.CTRL_MASK) > 0)
    		m += "Ctrl ";
	       	if ((mod & ActionEvent.META_MASK) > 0)
    		m += "Meta ";
	       	System.out.println("Modifieurs (touches du claviers appuy�es) :  " + m);
	       	
		// Afficher la commande d'action du bouton (par d�faut c'est le nom du bouton)
		System.out.println ("e.getActionCommand() : " + e.getActionCommand());

}
}
