/*
 * Une m�thode static est appel�e sans faire r�f�rence 
 * � un objet particulier.
 */

public class ExempleStatic {

	public static void afficherMeteo () {
		System.out.println ("Il fait beau !");
	}
	
	public static void main(String[] args) {
		afficherMeteo();
		// Depuis une autre classe C, il faudrait sp�cifier : 
		// ExempleStatic.afficherMeteo();
		// Attention, il faut que cette m�thode soit visible 
		// depuis cette classe C
	}
}
