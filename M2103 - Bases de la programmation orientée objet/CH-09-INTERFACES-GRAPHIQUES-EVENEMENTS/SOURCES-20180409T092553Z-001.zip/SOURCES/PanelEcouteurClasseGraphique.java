import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class PanelEcouteurClasseGraphique extends JPanel implements ActionListener {
	JButton b ;
	JTextField txt ;
	
	PanelEcouteurClasseGraphique () {
		// Creer les composants et les ajouter au panel
		b = new JButton ("Afficher");
		txt = new JTextField(20);
		add (b);
		add (txt);
		
        // Dire au bouton d'ajouter a sa liste de listener CET OBJET
        b.addActionListener (this);
	}
	
	// La classe graphique est aussi �couteur 
	// donc la m�thode actionPerformed a acc�s � tous les attributs
		public void actionPerformed(ActionEvent e) {
			System.out.println ("Contenu du champs de texte : " + txt.getText());
		}
	
	public static void main (String args []) {                        
		// Creer un panel
		PanelEcouteurClasseGraphique p = new PanelEcouteurClasseGraphique();

		// Creer une fenetre et y ajouter la fenetre
        JFrame f = new JFrame ("Fenetre");
        f.add (p);
        f.setSize (300, 200);
        f.setVisible (true);
    }
}
