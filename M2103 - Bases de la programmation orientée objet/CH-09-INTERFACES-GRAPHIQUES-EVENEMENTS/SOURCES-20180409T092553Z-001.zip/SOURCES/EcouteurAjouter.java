import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class EcouteurAjouter implements ActionListener {
	PanelAjouter p ;
	
	EcouteurAjouter (PanelAjouter p) {
		// Permettra d'acc�der aux textfield et 
		//au jlabel dans la m�thode actionPerformed
		this.p = p ; 
	}
	
	public void actionPerformed(ActionEvent arg0) {
		// R�cup�rer les 2 nombres
		String s1 = p.nb1.getText();
		int n1 = Integer.parseInt(s1);
		
		String s2 = p.nb2.getText();
		int n2 = Integer.parseInt(s2);
				
		// Calculer la somme
		int somme = n1 + n2 ;
		
		// Afficher le r�sultat
		p.resultat.setText(""+somme);
		//p.resultat.setText((new Integer(somme)).toString());
	}

}
