
public class ExempleStaticAttribut {
	static int nb ; 
	
	public static void afficherStatic () {
		System.out.println (nb);
	}

	public void afficherObjet () {
		System.out.println (nb);
	}

	public static void main(String[] args) {
		// Affichage de l'attribut static via une m�thode static
		afficherStatic();
		
		// Affichage de l'attribut static via 
		// une m�thode non static
		ExempleStaticAttribut e = new ExempleStaticAttribut();
		e.afficherObjet();
	}
}
