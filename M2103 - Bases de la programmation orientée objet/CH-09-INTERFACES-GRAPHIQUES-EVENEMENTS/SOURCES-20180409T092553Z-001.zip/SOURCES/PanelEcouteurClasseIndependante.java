import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class PanelEcouteurClasseIndependante extends JPanel {
	JButton b ;
	JTextField saisie ;
	
	PanelEcouteurClasseIndependante () {
		// Creer les composants et les ajouter au panel
		b = new JButton ("Afficher");
		saisie = new JTextField(20);
		add (saisie);
		add (b);
		
		// Cr��r un �couteur
		EcouteurTextField e = new EcouteurTextField(saisie);
		
		// AJouter cet �couteur au bouton
		b.addActionListener(e);
	}
	
	public static void main (String args []) {                        
		PanelEcouteurClasseIndependante p = new PanelEcouteurClasseIndependante();
        JFrame f = new JFrame ("Fenetre");
        f.add (p);
        f.setSize (500, 100);
        f.setVisible (true);
    }
}
