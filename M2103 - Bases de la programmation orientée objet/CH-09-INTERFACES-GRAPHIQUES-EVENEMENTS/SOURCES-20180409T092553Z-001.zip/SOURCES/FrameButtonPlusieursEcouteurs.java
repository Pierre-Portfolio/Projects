import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class FrameButtonPlusieursEcouteurs {
public static void main (String args []) {                        
                // Creer un bouton
                final JButton b = new JButton ("Bonjour");
                
                // Enregistrer un 1er �couteur aupr�s du bouton
                EcouteurAfficheActionEvent ecouteurAff = new EcouteurAfficheActionEvent();
                b.addActionListener (ecouteurAff);
                
                // Enregistrer un 2eme �couteur aupr�s du bouton
                b.addActionListener (ecouteurAff);
                
                // Creer une fenetre et y ajouter le bouton
                JFrame f = new JFrame ("Fenetre");
                f.add (b);
                f.setSize (300, 200);
                f.setVisible (true);
        }
}
