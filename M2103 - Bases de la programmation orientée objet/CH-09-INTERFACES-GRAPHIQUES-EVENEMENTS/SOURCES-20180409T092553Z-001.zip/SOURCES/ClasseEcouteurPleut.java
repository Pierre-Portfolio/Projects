import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ClasseEcouteurPleut implements ActionListener {
	// Instructions qui doivent etre 
	// executees lorsqu'on clique sur le bouton
	public void actionPerformed(ActionEvent arg0) {
		System.out.println ("Il pleut :-) ");
	}
}
