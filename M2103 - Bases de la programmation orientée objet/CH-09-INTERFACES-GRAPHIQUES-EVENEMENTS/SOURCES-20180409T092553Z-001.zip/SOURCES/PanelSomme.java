import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

// Cette classe calcule la somme de deux nombres saisis dans des champs de texte et affiche le r�sultat dans un JLabel lorsque l'on clique sur un bouton. 
// Extension possible avec 1 autre bouton multiplier
// Bouton permettant de changer l'affichage : + vs SOMME => utilisation de ActionCommande
public class PanelSomme extends JPanel {
	JButton ajouter ;
	JTextField nb1 ;
	JTextField nb2 ;
	JLabel resultat ; 
	
	PanelSomme () {
		// Creer les composants 
		ajouter = new JButton ("Ajouter");
		nb1 = new JTextField(20);
		nb2 = new JTextField(20);
		resultat = new JLabel();
		
		// Ajouter les composants au panel
		setLayout (new GridLayout (4, 1));
		add (nb1);
		add (nb2);
		add (ajouter);
		add (resultat);
		
        // Dire au bouton d'ajouter a sa liste de listener un �couteur ind�pendant
		// Passer en param�tre au constructeur de l'�couteur la r�f�rence sur le champ de texte
		EcouteurSomme e = new EcouteurSomme(this);
		ajouter.addActionListener (e);
	}
	
	public static void main (String args []) {                        
		PanelSomme p = new PanelSomme();
        JFrame f = new JFrame ("Somme");
        f.add (p);
        f.setSize (200, 200);
        f.setVisible (true);
    }
}
