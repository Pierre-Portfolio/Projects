import javax.swing.*;

public class FrameButton {
	public static void main (String args []) {                        
		// Creer un bouton
		JButton b = new JButton ("Bonjour");

		// Creer un objet ecouteur
		EcouteurAfficheActionEvent ecouteur = new EcouteurAfficheActionEvent();

		// Dire au bouton d'ajouter a sa liste de listener le listener
		// que l'on vient de creer 
		b.addActionListener (ecouteur);
		b.addActionListener (ecouteur);

		// Creer une fenetre et y ajouter le bouton
		JFrame f = new JFrame ("Fenetre");
		f.add (b);
		f.setSize (300, 200);
		f.setVisible (true);
	}
}
