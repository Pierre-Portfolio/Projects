import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class EcouteurAfficherTextField implements ActionListener {

	JTextField t ; 
	
	EcouteurAfficherTextField (JTextField t) {
		this.t = t;
	}
	
	public void actionPerformed(ActionEvent e) {		
		System.out.println ("Texte saisi : " + t.getText());
	}
}
