import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EcouteurSomme implements ActionListener {

	PanelSomme p ; 
	
	EcouteurSomme (PanelSomme p) {
		this.p = p;
	}
	
	public void actionPerformed(ActionEvent e) {		
		// R�cup�rer les deux nombres � ajouter
		String s1 = p.nb1.getText();
		int nb1 = Integer.parseInt(s1);
		String s2 = p.nb2.getText();
		int nb2 = Integer.parseInt(s2);
		
		// Calculer la somme
		int somme = nb1 + nb2 ; 
		
		// Afficher la somme
		p.resultat.setText(""+somme);
	}
}
