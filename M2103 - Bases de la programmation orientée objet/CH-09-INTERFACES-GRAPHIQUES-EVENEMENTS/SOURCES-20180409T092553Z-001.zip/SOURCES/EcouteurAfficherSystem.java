import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class EcouteurAfficherSystem implements ActionListener {

	public void actionPerformed(ActionEvent arg0) {
		System.out.println("Un evenement Action a �t� d�tect�");
	}

}
