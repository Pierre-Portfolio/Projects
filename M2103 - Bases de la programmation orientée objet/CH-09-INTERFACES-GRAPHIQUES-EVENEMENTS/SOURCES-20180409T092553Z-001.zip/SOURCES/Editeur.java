import javax.swing.*;

public class Editeur {
public static void main (String args []) {                
                JFrame frame ;
                frame = new JFrame ("Fenetre");
          
                // Creer un bouton
                JButton boutonBonjour ;                  
                boutonBonjour = new JButton ("Bonjour");
               	
                // Ajouter le panneau � la frame
                JPanel panel = new JPanel ();
                panel.add(boutonBonjour);
                frame.add (panel);
                
                // Creer un objet listener
                EcouteurAfficherSystem listener = new EcouteurAfficherSystem();
                
                // Dire au bouton d'ajouter a sa liste de listener le listener
                // que l'on vient de cr�er 
                boutonBonjour.addActionListener (listener);
                boutonBonjour.addActionListener (listener);
                
                // Fixer la taille de la fenetre
                frame.setSize (300, 200);

                // Afficher la fenetre
                frame.setVisible (true);
        }
}
