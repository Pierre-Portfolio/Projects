import java.awt.GridLayout;

import javax.swing.*;

public class PanelAjouter extends JPanel {
	// D�clarer les composants graphiques
	JTextField nb1 ; 
	JTextField nb2 ; 
	JButton plus ; 
	JLabel resultat ;
	
	PanelAjouter () {
		// Cr�er les composants
		nb1 = new JTextField();
		nb2 = new JTextField();
		plus = new JButton ("Ajouter");
		resultat = new JLabel ();
		
		// Ajouter ces composants dans ce panel
		setLayout (new GridLayout (4, 1));
		add (nb1);
		add (nb2);
		add (plus);
		add (resultat);
		
		// Cr�er un �couteur et l'ajouter au bouton
		EcouteurAjouter e = new EcouteurAjouter(this);
		plus.addActionListener(e);
		
	}
	
	public static void main (String args []) {                        
		PanelAjouter p = new PanelAjouter();
        JFrame f = new JFrame ("Somme");
        f.add (p);
        f.setSize (200, 200);
        f.setVisible (true);
    }
}
