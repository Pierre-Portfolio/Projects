import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class PanelEcouteur extends JPanel implements ActionListener {
	JButton b ;                        
	JTextField txt ;

	PanelEcouteur () {
		// Creer les composants et les ajouter au panel
		b = new JButton ("Afficher");
		txt = new JTextField(20);
		add (b);
		add (txt);

		// Dire au bouton d'ajouter a sa liste de listener CET OBJET
		b.addActionListener(this);
		
		// Faire en sorte d'afficher le contenu
		// lorsque l'on tape return dans le champ de texte
		txt.addActionListener(this);
	}

	// La classe graphique est aussi �couteur 
	// donc la m�thode actionPerformed a acc�s � tous les attributs
	public void actionPerformed(ActionEvent e) {
		String contenu = txt.getText();
		System.out.println(contenu);
		txt.setText("");
	}

	
	public static void main (String args []) {                        
		// Creer un bouton
		PanelEcouteur p = new PanelEcouteur();

		// Creer une fenetre et y ajouter le bouton
		JFrame f = new JFrame ("Fenetre");
		f.add (p);
		f.setSize (300, 200);
		f.setVisible (true);
	}
}