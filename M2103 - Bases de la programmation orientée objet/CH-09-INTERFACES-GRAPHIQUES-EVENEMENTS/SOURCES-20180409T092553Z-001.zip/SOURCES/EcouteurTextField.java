import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

public class EcouteurTextField implements ActionListener {
	
	private JTextField saisie;

	public EcouteurTextField(JTextField saisie) {
		// M�moriser l'adresse du champs de texte dans un attribut
		// pour pouvoir y acc�der plus tard
		// (lors du clic sur le bouton)
		this.saisie = saisie ; 
	}

	public void actionPerformed(ActionEvent arg0) {
		// Acc�der au champs de texte 
		// (son adresse a �t� m�moris�e dans un attribut
		// au moment de la cr�ation de l'�couteur)
		System.out.println("on a cliqu� sur le bouton");
		String contenu = saisie.getText();
		System.out.println("Contenu du champs de texte : " + contenu);
	}	
}
