	import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class FrameOk {

	public static void main (String args []) {                        
	                final JButton b = new JButton ("Bonjour");
	                
	                // Enregistrer un 1er �couteur aupr�s du bouton
	                Ecouteur ec = new Ecouteur();
	                b.addActionListener (ec);
	                b.addActionListener (ec);
	                	                
	                // Creer une fenetre et y ajouter le bouton
	                JFrame f = new JFrame ("Fenetre");
	                f.add (b);
	                f.setSize (300, 200);
	                f.setVisible (true);
	        }
	}

class Ecouteur implements ActionListener {

	public void actionPerformed(ActionEvent e) {
   		if (e.getSource() instanceof JButton) {
   			// Caster l'objet source de l'�v�nement en JButton
   			JButton boutonSource = (JButton) e.getSource();
       		System.out.println("Nom du bouton : " + boutonSource.getText());    			
   		}	
	}
}
