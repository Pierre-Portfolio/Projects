import javax.swing.JFrame;

// Creer une fenetre et appeler des methodes sur cette fenetre
public class FenetreSimple {

	public static void main(String[] args) {
		// Creer une fenetre
		JFrame fenetre ; 
		fenetre = new JFrame ("Vive les amphis");
	
		// Lui donner sa taille
		fenetre.setSize (300, 300);
		
		// Lui dire de terminer le programme quand on clique sur la petite croix
		fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Afficher la fenetre
		fenetre.setVisible(true);
		
		// Empecher � l'utilisateur de changer la taille � l'ex�cution
		// (Cette m�thode est h�rit�e de la classe Frame)
		// fenetre.setResizable(false);
		fenetre.setBounds (380, 380, 400, 400); 
	}
}
