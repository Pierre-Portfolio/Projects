import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelSaisieBouton extends PanelSaisie {

	// Rajouter un composant
	JButton b ;
	
	PanelSaisieBouton(String s) {
		super (s);
		
		// Creer le bouton
		b = new JButton ("Valider");
		
		// Ajouter le bouton dans CE panel : ceci est possible car PanelSaisieBouton h�rite de PanelSaisie 
		// qui h�rite elle-m�me de Panel
		add (b);
	}
	
	public static void main(String[] args) {
		// Creer une fenetre
		JFrame fenetre = new JFrame ("Test de ma classe PanelSaisieBouton");
		fenetre.setSize (500, 100);
		fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Creer une instance de ma classe
		PanelSaisieBouton p = new PanelSaisieBouton ("Identifiant");
		
		// Ajouter mon instance dans un des conteneurs de la fen?tre
		fenetre.getContentPane().add(p);
		
		// Afficher la fenetre
		fenetre.setVisible(true);
	}
}
