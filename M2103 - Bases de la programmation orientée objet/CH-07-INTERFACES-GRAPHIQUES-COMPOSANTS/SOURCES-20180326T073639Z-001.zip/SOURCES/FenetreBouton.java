import javax.swing.*;

// Creer une fenetre et y ajouter un bouton
public class FenetreBouton {
	public static void main(String[] args) {
		// Creer une fenetre
		JFrame fenetre = new JFrame ("Silence en amphi");
		fenetre.setSize (300, 300);
		fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Creer un bouton
		JButton bouton = new JButton ("Ok");

		// Ajouter le bouton dans un des conteneurs de la fenetre
		// (seul le dernier bouton ajout� s'affiche)
		fenetre.getContentPane().add(bouton);
		
		// Afficher la fenetre
		fenetre.setVisible(true);
	}
}
