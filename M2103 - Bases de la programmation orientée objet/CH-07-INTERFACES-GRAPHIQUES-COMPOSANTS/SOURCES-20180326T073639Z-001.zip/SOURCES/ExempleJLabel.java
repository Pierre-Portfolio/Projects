import javax.swing.*;

public class ExempleJLabel {

	public static void main(String[] args) {
		// Creer une fenetre
		JFrame fenetre = new JFrame ("Swing");
		fenetre.setSize (300, 300);
		fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
		// Creer un JLabel
		JLabel l = new JLabel ("Ok");
		
		// Ajouter une icone au label
		l.setIcon(new ImageIcon ("java.jpg"));
		
		// Changer le texte du label
		l.setText("<html>Vive <I>Java</I> </html>"); 
		
		// Changer l'alignement (par defaut : centre verticalement)
		l.setVerticalTextPosition (SwingConstants.BOTTOM);
		
		// Ajouter le label dans un des conteneurs de la fenetre
		fenetre.add(l);
			
		// Afficher la fenetre
		fenetre.setVisible(true);
	}
}
