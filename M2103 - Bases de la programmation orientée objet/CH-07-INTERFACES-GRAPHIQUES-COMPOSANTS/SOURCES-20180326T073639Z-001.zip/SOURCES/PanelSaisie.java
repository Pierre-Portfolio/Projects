import java.awt.Panel;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

// Etendre la classe Panel
public class PanelSaisie extends JPanel {
	// D�clarer les composants du panel en tant  qu'attributs pour qu'ils soient accessibles par toutes les m�thodes
	private JLabel l ;
	private JTextField t ; 
	
	PanelSaisie (String s) {
		// Cr�er les composants
		l = new JLabel (s);
		t = new JTextField (10); 
		
		// Ajouter les composants dans CE paneau : ceci est possible car cette classe h�rite de 
		// la classe JPanel donc on peut appeler la m�thode add
		add(l);
		add(t);
	}

	public static void main(String[] args) {
		// Creer une fenetre
		JFrame fenetre = new JFrame ("Test de ma classe PanelSaisie");
		fenetre.setSize (400, 100);
		fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Creer des instances de ma classe
		PanelSaisie p = new PanelSaisie ("Nom");
		PanelSaisie pp = new PanelSaisie ("Prenom");
		
		// Ajouter mon instance dans un des conteneurs de la fen?tre
		JPanel global = new JPanel();
		global.add(p);
		global.add(pp);
		
		fenetre.getContentPane().add(global);
		
		// Afficher la fenetre
		fenetre.setVisible(true);
	}
}
