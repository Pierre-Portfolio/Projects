import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.*;

public class ApplicationBorderLayout {

	public static void main(String[] args) {
		//Creation de la fenetre de l'application
		JFrame mainFrame = new JFrame("Exemple de BorderLayout");

		//Creation d'un panel
		JPanel panelBoutons = new JPanel();
		
		//Changement du layout du panel
		panelBoutons.setLayout(new BorderLayout());
		
		//Ajout des boutons
		panelBoutons.add(new JButton("North"), BorderLayout.NORTH);
		panelBoutons.add(new JButton("South"), BorderLayout.SOUTH);
		panelBoutons.add(new JButton("East"), BorderLayout.EAST);
		panelBoutons.add(new JButton("West"), BorderLayout.WEST);
		panelBoutons.add(new JButton("Center"), BorderLayout.CENTER);
		
		//Ajout du panel a la fenetre
		mainFrame.add(panelBoutons);

		//'Compactage' de la fenetre
		mainFrame.pack();
		
		//On quitte l'application quand la fenetre est fermee
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Affichage de la fenetre
		mainFrame.setVisible(true);
	}
}
