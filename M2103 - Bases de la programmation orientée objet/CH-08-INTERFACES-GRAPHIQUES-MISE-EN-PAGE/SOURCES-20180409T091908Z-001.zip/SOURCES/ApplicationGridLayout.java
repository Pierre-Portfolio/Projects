import java.awt.GridLayout;
import javax.swing.*;

public class ApplicationGridLayout {
	public static void main(String[] args) {
			//Creation de la fenetre de l'application
			JFrame mainFrame = new JFrame("Exemple de GridLayout");

			//Creation d'un panel
			JPanel panelBoutons = new JPanel();
			
			//Changement du layout du panel
			panelBoutons.setLayout(new GridLayout(3, 2));

			//Ajout des boutons
			panelBoutons.add(new JButton("Bouton 1"));
			panelBoutons.add(new JButton("Bouton 2"));
			panelBoutons.add(new JButton("Bouton 3"));
			panelBoutons.add(new JButton("Bouton 4"));
			panelBoutons.add(new JButton("Bouton 5"));

			//Ajout du panel a la fenetre
			mainFrame.add(panelBoutons);

			//'Compactage' de la fenetre
			mainFrame.pack();
			//mainFrame.setResizable (false);
			
			//On quitte l'application quand la fenetre est fermee
			mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
			//Affichage de la fenetre
			mainFrame.setVisible(true);
	}
}
