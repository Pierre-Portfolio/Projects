import java.awt.FlowLayout;
import javax.swing.*;

public class ApplicationFlowLayout {
	public static void main(String[] args) {
		// Cr�er la fenetre de l'application
		JFrame mainFrame = new JFrame("Exemple de FlowLayout");

		// Cr�er un panel
		JPanel panelBoutons = new JPanel();
		
		// Changer le layout du panel pour cadrer � gauche
		// (par d�faut, cela aurait �t� centr�)
		FlowLayout layout = new FlowLayout(); //FlowLayout.LEFT);
		panelBoutons.setLayout(layout);
		
		// Ajouter des boutons
		panelBoutons.add(new JButton("Bouton 1"));
		panelBoutons.add(new JButton("Bouton 2"));
		panelBoutons.add(new JButton("Bouton 3"));
		panelBoutons.add(new JButton("Bouton 4"));
		panelBoutons.add(new JButton("Bouton 5"));
		
		//Ajout du panel a la fenetre
		mainFrame.add(panelBoutons);
		
		//'Compactage' de la fenetre
		mainFrame.pack();
		
		//On quitte l'application quand la fenetre est fermee
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Affichage de la fenetre
		mainFrame.setVisible(true);
	}
}
